export const FaqsData:any = {
    "en":[]
};
