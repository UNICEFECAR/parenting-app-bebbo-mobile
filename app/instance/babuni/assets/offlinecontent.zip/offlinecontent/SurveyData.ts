export const SurveyData:any = {
    "bn": []
};
