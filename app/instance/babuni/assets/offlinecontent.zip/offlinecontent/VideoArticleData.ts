export const VideoArticleData:any = {
    "bn":[]
};
