export const dailyHomeNotificationdata:any = {  
    "bn": []
};
